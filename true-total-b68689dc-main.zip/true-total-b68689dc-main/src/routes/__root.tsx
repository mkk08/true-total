import { Outlet, Link, createRootRoute, HeadContent, Scripts } from "@tanstack/react-router";

import appCss from "../styles.css?url";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">
          Page not found
        </h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "True Total: See Real Prices Before Checkout" },
      { name: "description", content: "True Total is a free Chrome extension that shows estimated total prices including tax and shipping on Shopify product pages." },
      { name: "author", content: "Lovable" },
      { property: "og:title", content: "True Total: See Real Prices Before Checkout" },
      { property: "og:description", content: "True Total is a free Chrome extension that shows estimated total prices including tax and shipping on Shopify product pages." },
      { property: "og:type", content: "website" },
      { property: "og:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/4501ec76-875b-4e0b-887d-2e4991fd4805/id-preview-8972f981--39788498-e711-42cd-89a3-7db4bb7af2f6.lovable.app-1775456407969.png" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:site", content: "@Lovable" },
      { name: "twitter:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/4501ec76-875b-4e0b-887d-2e4991fd4805/id-preview-8972f981--39788498-e711-42cd-89a3-7db4bb7af2f6.lovable.app-1775456407969.png" },
      { name: "twitter:title", content: "True Total: See Real Prices Before Checkout" },
      { name: "twitter:description", content: "True Total is a free Chrome extension that shows estimated total prices including tax and shipping on Shopify product pages." },
    ],
    links: [
      {
        rel: "stylesheet",
        href: appCss,
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  return <Outlet />;
}
