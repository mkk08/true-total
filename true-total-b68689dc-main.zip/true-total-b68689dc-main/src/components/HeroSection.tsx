import { motion } from "framer-motion";
import logo from "@/assets/tt-logo.png";
import screenshotProduct from "@/assets/screenshot-product.png";

const CHROME_STORE_URL = "https://chromewebstore.google.com/detail/ckfncahcdopjmecgnbplpnoofikgdnjb?utm_source=item-share-cb";

export default function HeroSection() {
  return (
    <section className="relative overflow-hidden bg-hero-bg py-20 md:py-32">
      {/* Decorative blobs */}
      <div className="pointer-events-none absolute -top-40 -right-40 h-[500px] w-[500px] rounded-full bg-hero-accent/30 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-40 -left-40 h-[400px] w-[400px] rounded-full bg-primary/20 blur-3xl" />

      <div className="relative mx-auto max-w-6xl px-6">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          {/* Text */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: "easeOut" }}
          >
            <div className="mb-6 flex items-center gap-3">
              <img src={logo} alt="True Total logo" className="h-12 w-12" />
              <span className="text-2xl font-bold tracking-tight text-foreground">
                True Total
              </span>
            </div>

            <h1 className="text-4xl font-bold leading-tight tracking-tight text-foreground md:text-5xl lg:text-6xl">
              See the <span className="text-primary">real price</span> before
              checkout
            </h1>

            <p className="mt-6 max-w-lg text-lg leading-relaxed text-muted-foreground">
              True Total shows estimated total prices — including sales tax and
              shipping — right on Shopify product pages. No more surprises at
              checkout.
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-4">
              <a
                href={CHROME_STORE_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 rounded-xl bg-foreground px-6 py-3.5 text-sm font-semibold text-background transition hover:opacity-90"
              >
                <ChromeIcon />
                Add to Chrome — Free
              </a>
              <span className="rounded-lg bg-badge-bg px-3 py-1.5 text-xs font-medium text-badge-foreground">
                100% Free
              </span>
            </div>
          </motion.div>

          {/* Screenshot */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.2, ease: "easeOut" }}
            className="relative"
          >
            <div className="overflow-hidden rounded-2xl border border-border bg-card shadow-2xl shadow-primary/10">
              <img
                src={screenshotProduct}
                alt="True Total showing estimated total price on a Shopify product page"
                className="w-full"
              />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

function ChromeIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" className="shrink-0">
      <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2" />
      <circle cx="12" cy="12" r="4" stroke="currentColor" strokeWidth="2" />
      <path d="M21.17 8H12" stroke="currentColor" strokeWidth="2" />
      <path d="M3.95 6.06L8.54 14" stroke="currentColor" strokeWidth="2" />
      <path d="M10.88 21.94L15.46 14" stroke="currentColor" strokeWidth="2" />
    </svg>
  );
}
