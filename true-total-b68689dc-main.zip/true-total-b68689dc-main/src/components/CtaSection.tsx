import { motion } from "framer-motion";

const CHROME_STORE_URL = "https://chromewebstore.google.com/detail/ckfncahcdopjmecgnbplpnoofikgdnjb?utm_source=item-share-cb";

export default function CtaSection() {
  return (
    <section className="bg-background py-24">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="mx-auto max-w-3xl px-6 text-center"
      >
        <h2 className="text-3xl font-bold tracking-tight text-foreground md:text-4xl">
          Stop guessing. Start seeing real prices.
        </h2>
        <p className="mt-4 text-lg text-muted-foreground">
          Join shoppers who already know what they'll pay before checkout.
          True Total is free — no account needed.
        </p>
        <div className="mt-8">
          <a
            href={CHROME_STORE_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 rounded-xl bg-foreground px-8 py-4 text-sm font-semibold text-background transition hover:opacity-90"
          >
            Add True Total to Chrome
          </a>
        </div>
      </motion.div>
    </section>
  );
}
