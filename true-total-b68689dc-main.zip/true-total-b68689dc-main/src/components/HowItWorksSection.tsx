import { motion } from "framer-motion";
import screenshotCollection from "@/assets/screenshot-collection.png";
import screenshotSettings from "@/assets/screenshot-settings.png";

const steps = [
  {
    number: "1",
    title: "Install the Extension",
    description: "Add True Total to Chrome in one click. It's free and lightweight.",
  },
  {
    number: "2",
    title: "Enter Your ZIP Code",
    description: "Set your location so the extension can estimate your local sales tax rate.",
  },
  {
    number: "3",
    title: "Shop with Confidence",
    description: "Browse any Shopify store and see estimated total prices — tax and shipping included — on every product.",
  },
];

export default function HowItWorksSection() {
  return (
    <section id="how-it-works" className="bg-feature-bg py-24">
      <div className="mx-auto max-w-6xl px-6">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight text-foreground md:text-4xl">
            How it works
          </h2>
          <p className="mt-4 text-muted-foreground">
            Three steps to seeing real prices everywhere you shop.
          </p>
        </div>

        {/* Steps */}
        <div className="mt-16 grid gap-8 md:grid-cols-3">
          {steps.map((step, i) => (
            <motion.div
              key={step.number}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.15, duration: 0.5 }}
              className="text-center"
            >
              <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-primary text-2xl font-bold text-primary-foreground">
                {step.number}
              </div>
              <h3 className="mt-5 text-lg font-semibold text-foreground">
                {step.title}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {step.description}
              </p>
            </motion.div>
          ))}
        </div>

        {/* Screenshots */}
        <div className="mt-20 grid gap-8 md:grid-cols-2">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="overflow-hidden rounded-2xl border border-border bg-card shadow-lg"
          >
            <img
              src={screenshotCollection}
              alt="True Total showing prices on a Shopify collection page"
              className="w-full"
            />
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="overflow-hidden rounded-2xl border border-border bg-card shadow-lg"
          >
            <img
              src={screenshotSettings}
              alt="True Total settings — set tax by ZIP code or manually"
              className="w-full"
            />
          </motion.div>
        </div>
      </div>
    </section>
  );
}
