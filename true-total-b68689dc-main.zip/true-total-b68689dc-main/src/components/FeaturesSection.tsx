import { motion } from "framer-motion";
import { Eye, MapPin, ShieldCheck, DollarSign } from "lucide-react";

const features = [
  {
    icon: Eye,
    title: "See Real Prices Instantly",
    description:
      "Estimated totals — with tax and shipping — appear right on product and collection pages. No clicking into checkout required.",
  },
  {
    icon: MapPin,
    title: "Tax by ZIP Code",
    description:
      "Enter your ZIP code to get a local sales tax estimate, or set a manual rate. Either way, it's fast and simple.",
  },
  {
    icon: ShieldCheck,
    title: "Runs Locally & Privately",
    description:
      "Everything happens in your browser. No data is sent to external servers. Your browsing stays private.",
  },
  {
    icon: DollarSign,
    title: "Completely Free",
    description:
      "No subscriptions, no premium tiers, no ads. True Total is free to use — period.",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: { staggerChildren: 0.12 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 24 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: "easeOut" as const } },
};

export default function FeaturesSection() {
  return (
    <section id="features" className="bg-background py-24">
      <div className="mx-auto max-w-6xl px-6">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight text-foreground md:text-4xl">
            Shop smarter, not harder
          </h2>
          <p className="mt-4 text-muted-foreground">
            True Total makes online prices transparent so you can make better
            spending decisions.
          </p>
        </div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
          className="mt-16 grid gap-8 sm:grid-cols-2"
        >
          {features.map((f) => (
            <motion.div
              key={f.title}
              variants={itemVariants}
              className="group rounded-2xl border border-border bg-card p-8 transition hover:shadow-lg hover:shadow-primary/5"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-accent text-primary">
                <f.icon className="h-6 w-6" />
              </div>
              <h3 className="mt-5 text-xl font-semibold text-foreground">
                {f.title}
              </h3>
              <p className="mt-2 leading-relaxed text-muted-foreground">
                {f.description}
              </p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
