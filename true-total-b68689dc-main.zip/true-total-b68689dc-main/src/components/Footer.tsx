import logo from "@/assets/tt-logo.png";

export default function Footer() {
  return (
    <footer className="border-t border-border bg-muted py-10">
      <div className="mx-auto flex max-w-6xl flex-col items-center gap-4 px-6 text-center">
        <div className="flex items-center gap-2">
          <img src={logo} alt="True Total" className="h-7 w-7" />
          <span className="font-semibold text-foreground">True Total</span>
        </div>
        <p className="text-sm text-muted-foreground">
          Free Chrome extension for transparent online pricing.
        </p>
        <p className="text-xs text-muted-foreground/70">
          © {new Date().getFullYear()} True Total. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
